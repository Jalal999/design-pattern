
import java.util.*;

/**
 * 
 */
public abstract class displayUI {

    /**
     * Default constructor
     */
    public displayUI() {
    }

    /**
     * 
     */
    public String designType;

    /**
     * 
     */
    public String[] UI_items;

    /**
     * 
     */
    abstract void displayUIitems();

}